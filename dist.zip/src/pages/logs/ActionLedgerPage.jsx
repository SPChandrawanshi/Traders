import React, { useState } from 'react';
import { Search, RotateCcw, Clock } from 'lucide-react';

const ActionLedgerPage = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [activeSearchTerm, setActiveSearchTerm] = useState('');

    const logs = [
        {
            id: 1,
            message: 'Scrip COPPER26FEBFUT removed from ban by SHRISHREENATHJI TRADERS admin.',
            createdAt: '2026-02-03 01:12:18'
        },
        {
            id: 2,
            message: 'Scrip COPPER26FEBFUT added to ban by SHRISHREENATHJI TRADERS admin.',
            createdAt: '2026-02-03 01:12:15'
        },
        {
            id: 3,
            message: 'SHRE0259 (4334) Buy Order of 2.00000000 lots of GOLDM26FEBFUT executed successfully at Rs.141540. Funds available=124899.6342 . Funds Required=2000 (EXIT) (BY ADMIN)',
            createdAt: '2026-02-03 00:54:59'
        },
        {
            id: 4,
            message: 'COM2: Trade 4239500 closed. Order ID: 4239661. Parent: 4239500. Exec. Price: 141540.00000000. Parent Price: 141201.00000000 . Parent & Exec. Qty: 20.',
            createdAt: '2026-02-03 00:54:59'
        },
        {
            id: 5,
            message: 'COM1: Trade 4239661 closed. Order ID: 4239661. Parent: 4239500. Exec. Price: 141540.00000000. Parent Price: 141201.00000000 . Parent & Exec. Qty: 20.',
            createdAt: '2026-02-03 00:54:59'
        },
         {
            id: 6,
            message: 'COM3: Trade 4239500 closed. Parent: 4239500. Exec. Price: 141540.00000000.Parent Price: 141201.00000000 . Parent & Exec. Qty: 20.',
            createdAt: '2026-02-03 00:54:59'
        }
    ];

    const filteredLogs = logs.filter(log => 
        log.message.toLowerCase().includes(activeSearchTerm.toLowerCase())
    );

    const handleSearch = () => {
        setActiveSearchTerm(searchTerm);
    };

    const handleReset = () => {
        setSearchTerm('');
        setActiveSearchTerm('');
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            handleSearch();
        }
    };

    const MobileLogCard = ({ log }) => (
        <div className="bg-[#151c2c] p-4 rounded-lg border border-[#2d3748] shadow-md mb-3 active:scale-[0.98] transition-transform">
            <div className="flex items-start gap-3">
                <div className="flex-1">
                     <p className="text-sm text-slate-300 leading-relaxed mb-3">{log.message}</p>
                     <div className="flex items-center justify-end text-[10px] text-slate-500 font-mono border-t border-[#2d3748] pt-2">
                        <Clock className="w-3 h-3 mr-1" /> {log.createdAt}
                    </div>
                </div>
            </div>
        </div>
    );

    return (
        <div className="flex flex-col h-full bg-[#0b111e] overflow-y-auto custom-scrollbar">
            {/* Search Section */}
            <div className="p-4 md:p-6 bg-[#151c2c] border-b border-[#2d3748]">
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-6 items-end">
                    <div className="md:col-span-8 space-y-2">
                        <label className="text-slate-400 text-sm font-medium">Message</label>
                        <input 
                            type="text" 
                            className="w-full bg-[#0b111e] border-b border-slate-600 text-white py-2 px-1 focus:outline-none focus:border-blue-500 transition-colors"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            onKeyDown={handleKeyDown}
                        />
                    </div>
                    <div className="md:col-span-4 flex gap-4">
                        <button 
                            onClick={handleSearch}
                            className="flex-1 bg-[#4CAF50] hover:bg-green-600 text-white font-bold py-2 px-4 rounded shadow-lg uppercase text-sm transition-all flex items-center justify-center gap-2"
                        >
                            <Search className="w-4 h-4" /> Search
                        </button>
                        <button 
                            onClick={handleReset}
                            className="flex-1 bg-slate-600 hover:bg-slate-500 text-white font-bold py-2 px-4 rounded shadow-lg uppercase text-sm transition-all flex items-center justify-center gap-2"
                        >
                            <RotateCcw className="w-4 h-4" /> Reset
                        </button>
                    </div>
                </div>
            </div>

            {/* Logs List/Table */}
            <div className="p-4 md:p-6">
                 {/* Desktop Table View */}
                <div className="hidden md:block bg-[#151c2c] rounded border border-[#2d3748] overflow-hidden shadow-xl">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="text-slate-200 text-sm font-semibold border-b border-[#2d3748] bg-[#151c2c]">
                                <th className="px-6 py-4">Message</th>
                                <th className="px-6 py-4 w-48 text-right">Created At</th>
                            </tr>
                        </thead>
                        <tbody className="text-sm font-medium text-slate-300 divide-y divide-[#2d3748]">
                            {filteredLogs.length > 0 ? (
                                filteredLogs.map((log) => (
                                    <tr key={log.id} className="hover:bg-slate-800/20 transition-colors">
                                        <td className="px-6 py-4 leading-relaxed">
                                            {log.message}
                                        </td>
                                        <td className="px-6 py-4 text-right text-slate-400 whitespace-pre-wrap">
                                            {log.createdAt.replace(' ', '\n')}
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan="2" className="px-6 py-8 text-center text-slate-500 italic">
                                        No logs found matching "{searchTerm}"
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>

                {/* Mobile Card List View */}
                <div className="md:hidden space-y-3 pb-20">
                     {filteredLogs.length > 0 ? (
                        filteredLogs.map((log) => (
                            <MobileLogCard key={log.id} log={log} />
                        ))
                    ) : (
                        <div className="text-center text-slate-500 italic py-8">
                             No logs found matching "{searchTerm}"
                        </div>
                    )}
                </div>
                
                {/* Pagination */}
                 <div className="mt-4 flex justify-between items-center text-xs text-slate-500 px-2">
                    <div>Showing {filteredLogs.length} of {logs.length} entries</div>
                    <div className="flex gap-1">
                        <button className="px-3 py-1 bg-[#151c2c] border border-[#2d3748] rounded hover:border-slate-500 transition-colors text-slate-300">1</button>
                        <button className="px-3 py-1 bg-[#151c2c] border border-[#2d3748] rounded hover:border-slate-500 transition-colors text-slate-300">2</button>
                        <button className="px-3 py-1 bg-[#151c2c] border border-[#2d3748] rounded hover:border-slate-500 transition-colors text-slate-300">3</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ActionLedgerPage;
